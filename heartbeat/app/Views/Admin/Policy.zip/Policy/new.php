<?= $this->extend("Layouts/default") ?>
<?= $this->section("title") ?>New <?= $const["item"]; ?><?= $this->endSection() ?>

<?= $this->section("headercss") ?><?= $this->endSection() ?>
<?= $this->section("headerjs") ?><?= $this->endSection() ?>

<?= $this->section("content") ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">New <?= ITEM ?></h5>
            </div>
            <div class="card-body">
                <?= $this->include($const['viewfolder'].'form') ?>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section("footerjs") ?><?= $this->endSection() ?>

<?php
// $data is the Policy entity
$isEdit = isset($const['id']) && !empty($const['id']);
?>

<?php if (session()->has('error')) : ?>
    <div class="row">
        <div class="col">
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0px;">
                    <?php foreach ((array)session('error') as $error) : ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif ?>

<form method="post" 
      action="<?= $isEdit ? site_url($const['route'].'/update/'.$const['id']) : site_url($const['route'].'/create'); ?>">
  <?= csrf_field(); ?>

  <!-- Product -->
  <div class="row">
    <div class="col-xxl-6 col-md-6">
      <label for="productId" class="form-label">Product</label>
      <select name="productId" id="productId" class="form-select" required>
        <option value="">Select Product</option>
        <?php foreach ($productOptions as $id => $name): ?>
          <option value="<?= $id ?>" 
            <?= old('productId', $data->productId ?? '') == $id ? 'selected' : '' ?>>
            <?= esc($name) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>

  <!-- Start & End Date -->
  <div class="row mt-3">
    <div class="col-xxl-3 col-md-4">
      <label class="form-label">Start Date</label>
      <input type="date" name="startDate" class="form-control" 
             value="<?= old('startDate', $data->startDate ?? '') ?>" required>
    </div>
    <div class="col-xxl-3 col-md-4">
      <label class="form-label">End Date</label>
      <input type="date" name="endDate" class="form-control" 
             value="<?= old('endDate', $data->endDate ?? '') ?>" required>
    </div>
    <div class="col-xxl-3 col-md-4">
      <label class="form-label">Status</label>
      <select name="status" class="form-select">
        <option value="Active" <?= old('status', $data->status ?? '') == 'Active' ? 'selected' : '' ?>>Active</option>
        <option value="Expired" <?= old('status', $data->status ?? '') == 'Expired' ? 'selected' : '' ?>>Expired</option>
      </select>
    </div>
  </div>

  <!-- Dynamic Attributes (AJAX loaded) -->
  <div class="row mt-4">
    <div class="col-12">
      <h5>Attributes</h5>
      <div id="attributes-wrapper">
        <?php if (!empty($attributes)): ?>
          <?= $this->include($const['viewfolder'].'_attributes'); ?>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <button type="submit" class="btn btn-success mt-3">Save</button>
  <a href="<?= site_url($const["route"]); ?>" class="btn btn-secondary mt-3">Cancel</a>
</form>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const productSelect = document.querySelector('select[name="productId"]'); // ✅ fixed
    const attributesWrapper = document.getElementById("attributes-wrapper");

    if (!productSelect) {
        console.error("Product select not found");
        return;
    }

    productSelect.addEventListener("change", function () {
        const productId = this.value;

        if (productId) {
            fetch("<?= site_url($const['route'].'/attributes'); ?>/" + productId)
                .then(response => response.text())
                .then(html => {
                    attributesWrapper.innerHTML = html;
                })
                .catch(err => {
                    console.error("Failed to load attributes", err);
                });
        } else {
            attributesWrapper.innerHTML = "";
        }
    });
});

</script>

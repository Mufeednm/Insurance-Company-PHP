<?= $this->extend('Admin/layout') ?>
<?= $this->section('content') ?>

<h4 class="mb-3">Delete <?= $const['item'] ?></h4>

<div class="alert alert-warning">
    Are you sure you want to delete this <?= strtolower($const['item']) ?>?
</div>

<ul>
    <li><strong>Product:</strong> <?= esc($productName) ?></li>
    <li><strong>Start Date:</strong> <?= esc($data->startDate) ?></li>
    <li><strong>End Date:</strong> <?= esc($data->endDate) ?></li>
    <li><strong>Status:</strong> <?= esc($data->status) ?></li>
</ul>

<form method="post" action="<?= site_url($const['route'] . '/delete/' . $const['id']) ?>">
    <?= csrf_field() ?>
    <button type="submit" class="btn btn-danger">Yes, Delete</button>
    <a href="<?= site_url($const['route']) ?>" class="btn btn-secondary">Cancel</a>
</form>

<?= $this->endSection() ?>
    
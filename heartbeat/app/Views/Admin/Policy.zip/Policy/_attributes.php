<?php
/**
 * Partial: _attributes.php
 * Expects:
 *   - $attributes : array of attribute Entities (may be empty)
 *   - $values     : associative array [attributeId => value|string|array] (may be empty)
 */

if (!isset($attributes) || !is_array($attributes)) {
    $attributes = [];
}
if (!isset($values) || !is_array($values)) {
    $values = [];
}

/**
 * Parse stored options like ["opt1"|"opt2"] into PHP array
 */
function parseOptionsString($s) {
    $s = (string)$s;
    if ($s === '') return [];
    // match ["..."] pattern
    if (preg_match('/^\[\s*"(.*)"\s*\]$/', $s, $m)) {
        $inside = $m[1];
        // split by "|"
        return array_map('trim', explode('"|"', $inside));
    }
    // fallback: try pipe
    if (strpos($s, "|") !== false) {
        return array_map('trim', explode("|", $s));
    }
    // fallback: newline
    if (strpos($s, "\n") !== false) {
        return array_map('trim', preg_split("/\r\n|\n|\r/", $s));
    }
    // single item
    return [trim($s)];
}

if (empty($attributes)) {
    echo '<div class="alert alert-info">No attributes defined for this product.</div>';
    return;
}

foreach ($attributes as $attr) :
    // $attr is an Entity object; access as properties
    $id   = (int)$attr->attributeId;
    $label = esc($attr->attributeName);
    $type  = $attr->attributeType;
    $required = ($attr->isRequired == 1);
    $attrOrder = (int)$attr->attributeOrder;
    $attrOptions = [];
    if (!empty($attr->options)) {
        $attrOptions = parseOptionsString($attr->options);
    }

    // get existing value if present
    $val = $values[$id] ?? null;

    // wrapper row
    echo '<div class="row mb-3 attribute-row" data-attribute-id="'.$id.'">';
    echo '<div class="col-12">';
    echo '<label class="form-label">'. $label;
    if ($required) echo ' <span class="text-danger">*</span>';
    echo '</label>';

    // render input by type
    switch ($type) {
        case 'textarea':
            $v = is_array($val) ? implode("\n", $val) : ($val ?? '');
            echo '<textarea name="attributes['.$id.']" class="form-control" rows="3" '.($required?'required':'').'>'.esc(old("attributes.$id", $v)).'</textarea>';
            break;

        case 'select':
            echo '<select name="attributes['.$id.']" class="form-select" '.($required?'required':'').'>';
            echo '<option value="">-- Select --</option>';
            foreach ($attrOptions as $opt) {
                $sel = ((string)($val ?? '') === (string)$opt) ? 'selected' : '';
                echo '<option value="'.esc($opt).'" '.$sel.'>'.esc($opt).'</option>';
            }
            echo '</select>';
            break;

        case 'checkbox':
            // $attrOptions expected. Multiple values allowed => name as array
            foreach ($attrOptions as $opt) {
                $checked = false;
                if (is_array($val)) {
                    $checked = in_array($opt, $val, true);
                } else {
                    $checked = ((string)$val === (string)$opt);
                }
                echo '<div class="form-check form-check-inline">';
                echo '<input class="form-check-input" type="checkbox" name="attributes['.$id.'][]" value="'.esc($opt).'" '.($checked?'checked':'').' id="attr_'.$id.'_'.md5($opt).'">';
                echo '<label class="form-check-label" for="attr_'.$id.'_'.md5($opt).'">'.esc($opt).'</label>';
                echo '</div> ';
            }
            break;

        case 'radio':
            foreach ($attrOptions as $opt) {
                $checked = ((string)$val === (string)$opt);
                echo '<div class="form-check form-check-inline">';
                echo '<input class="form-check-input" type="radio" name="attributes['.$id.']" value="'.esc($opt).'" '.($checked?'checked':'').' id="attr_'.$id.'_'.md5($opt).'">';
                echo '<label class="form-check-label" for="attr_'.$id.'_'.md5($opt).'">'.esc($opt).'</label>';
                echo '</div> ';
            }
            break;

        case 'number':
            $v = $val ?? '';
            echo '<input type="number" name="attributes['.$id.']" class="form-control" value="'.esc(old("attributes.$id", $v)).'" '.($required?'required':'').'>';
            break;

        case 'date':
            // keep date format YYYY-MM-DD for input[type=date]
            $v = $val ?? '';
            echo '<input type="date" name="attributes['.$id.']" class="form-control" value="'.esc(old("attributes.$id", $v)).'" '.($required?'required':'').'>';
            break;

        case 'text':
        default:
            $v = is_array($val) ? implode('|', $val) : ($val ?? '');
            echo '<input type="text" name="attributes['.$id.']" class="form-control" value="'.esc(old("attributes.$id", $v)).'" '.($required?'required':'').'>';
            break;
    }

    echo '</div>'; // col-12
    echo '</div>'; // row
endforeach;

<?php

namespace App\Controllers\Admin;

class Reports extends \App\Controllers\BaseController
{
    public function __construct()
    {
        $this->current_user = service('auth')->getCurrentUser();
        $this->policies = new \App\Models\Policies();
        $this->products = new \App\Models\Products();
        define('VIEWFOLDER', 'Admin/Report/');
        define('ROUTE', 'admin/reports');
        session()->set('activate', "reports");
    }

    public function index()
    {
        $const = [
        'viewfolder' => VIEWFOLDER,
        'route'      => ROUTE,
    ];
        $tableArray = [];

        if ($this->request->getMethod() === 'post') {
            $post = $this->request->getPost();
            $reportRange = $post["reportRange"] ?? '';
            $productId   = $post["productId"] ?? '';
dd($productId);
            // Parse date range
            $from = $to = date("Y-m-d");
            if (!empty($reportRange)) {
                $dateSplit = explode(" to ", $reportRange);
                $from = date("Y-m-d", strtotime($dateSplit[0]));
                $to   = (count($dateSplit) === 2) ? date("Y-m-d", strtotime($dateSplit[1])) : $from;
            }

            // Build query
            $builder = $this->policies
                ->select('policies.policyId, policies.policyNumber, policies.customerName, policies.customerphone, policies.status, policies.created_at, products.productId, products.name as productName')
                ->join('products', 'policies.productId = products.productId', 'left')
                ->where('DATE(policies.created_at) >=', $from)
                ->where('DATE(policies.created_at) <=', $to);

            if (!empty($productId)) {
                $builder->where('policies.productId', $productId);
            }

            $query = $builder->findAll();

            foreach ($query as $row) {
                $tableArray[] = [
                    'policyId'      => $row->policyId,
                    'policyNumber'  => $row->policyNumber,
                    'customerName'  => $row->customerName,
                    'customerphone' => $row->customerphone,
                    'status'        => $row->status,
                    'productName'   => $row->productName,
                    'created_at'    => $row->created_at,
                ];
            }

            $data = [
                'table'    => $tableArray,
                'post'     => $post,
                'products' => $this->products->findAll()
            ];

            return view(VIEWFOLDER . 'index', ['const' => $const, 'data' => $data]);
        }

        // GET
        $data = [
            'table'    => [],
            'post'     => [],
            'products' => $this->products->findAll()
        ];
        return view(VIEWFOLDER . 'index', ['const' => $const, 'data' => $data]);
    }
}

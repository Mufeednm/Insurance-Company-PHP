<?= $this->extend("layouts/default") ?>
<?= $this->section("title") ?>Policies Report<?= $this->endSection() ?>

<?= $this->section("headercss") ?>
<link href="<?= site_url(''); ?>plugins/flatpickr/flatpickr.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?= site_url(''); ?>plugins/select2/select2.min.css">
<link rel="stylesheet" type="text/css" href="<?= site_url(''); ?>plugins/table/datatable/datatables.css">
<link rel="stylesheet" type="text/css" href="<?= site_url(''); ?>plugins/table/datatable/custom_dt_html5.css">
<link rel="stylesheet" type="text/css" href="<?= site_url(''); ?>plugins/table/datatable/dt-global_style.css">
<link href="<?= site_url(''); ?>assets/css_light/tables/table-basic.css" rel="stylesheet" type="text/css" />
<?= $this->endSection() ?>

<?= $this->section("content") ?>
<div id="content" class="main-content">
    <div class="layout-px-spacing mt-4">
        <div class="page-header">
            <div class="page-title">
                <h3>Policies report</h3>
            </div>
            <nav class="breadcrumb-one" aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= site_url(); ?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Reports</a></li>
                    <li class="breadcrumb-item active"><a href="#">Policies report</a></li>
                </ol>
            </nav>
        </div>

        <!-- Filters -->
        <div class="row mb-3">
            <div class="col-lg-12">
                <div class="statbox widget box box-shadow">
                    <div class="widget-content widget-content-area" style="padding-bottom:0px;">
                    <form id="report" action="<?= site_url($const['route']) ?>" method="post">
    <?= csrf_field() ?>

                        <div class="row">
                            <!-- Date Range -->
                            <div class="col-lg-4">
                                <input name="reportRange" id="reportRange" class="form-control flatpickr" type="text" placeholder="Select Date Range"
                                    value="<?= !empty($data['post']['reportRange']) ? esc($data['post']['reportRange']) : '' ?>">
                            </div>
                            <!-- Product -->
                            <div class="col-lg-5">
                                <select class="form-control select2 d-block w-100" id="productId" name="productId">
                                    <option value="">All Products</option>
                                    <?php foreach ($data['products'] as $prod): ?>
                                        <?php
                                            $selected = (!empty($data['post']['productId']) && $data['post']['productId'] == $prod->productId) ? 'selected' : '';
                                        ?>
                                        <option value="<?= esc($prod->productId) ?>" <?= $selected ?>><?= esc($prod->name) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <!-- Button -->
                            <div class="col-lg-3" style="padding-top:3px;">
                                <button type="submit" class="btn btn-info mb-2 mr-2">
                                    Generate Report
                                </button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Results Table -->
        <?php if (!empty($data['table'])): ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="widget-content widget-content-area">
                    <div class="table-responsive mb-4 mt-2">
                        <table id="reportTable" class="table table-hover" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Policy Number</th>
                                    <th>Customer</th>
                                    <th>Phone</th>
                                    <th>Status</th>
                                    <th>Product</th>
                                    <th>Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data['table'] as $row): ?>
                                <tr>
                                    <td><?= esc($row['policyId']) ?></td>
                                    <td><?= esc($row['policyNumber']) ?></td>
                                    <td><?= esc($row['customerName']) ?></td>
                                    <td><?= esc($row['customerphone']) ?></td>
                                    <td><?= esc($row['status']) ?></td>
                                    <td><?= esc($row['productName']) ?></td>
                                    <td><?= esc($row['created_at']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section("footerjs") ?>
<script src="<?= site_url(''); ?>plugins/flatpickr/flatpickr.js"></script>
<script src="<?= site_url(''); ?>plugins/select2/select2.min.js"></script>
<script src="<?= site_url(''); ?>plugins/table/datatable/datatables.js"></script>
<script src="<?= site_url(''); ?>plugins/table/datatable/button-ext/dataTables.buttons.min.js"></script>
<script src="<?= site_url(''); ?>plugins/table/datatable/button-ext/jszip.min.js"></script>
<script src="<?= site_url(''); ?>plugins/table/datatable/button-ext/buttons.html5.min.js"></script>
<script src="<?= site_url(''); ?>plugins/table/datatable/button-ext/buttons.print.min.js"></script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // flatpickr - range
    flatpickr("#reportRange", { mode: "range", dateFormat: "Y-m-d" });

    // select2
    $('#productId').select2({ width: '100%' });

    // DataTable with export buttons
    $('#reportTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            { extend: 'copy', className: 'btn' },
            { extend: 'csv', className: 'btn' },
            { extend: 'excel', className: 'btn' },
            { extend: 'print', className: 'btn' }
        ],
        responsive: true,
        pageLength: 25,
        order: []
    });
});
</script>
<?= $this->endSection() ?>

<?= $this->extend("Layouts/default") ?>
<?= $this->section("title") ?>New <?= $const["item"]; ?><?= $this->endSection() ?>
<?= $this->section("headercss") ?><?= $this->endSection() ?>
<?= $this->section("headerjs") ?><?= $this->endSection() ?>
<?= $this->section("content") ?>

<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0"><?= $const["items"]; ?></h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Policies</a></li>
                    <li class="breadcrumb-item active">New <?= $const["item"]; ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
  <div class="col-lg-12">
    <?= form_open(ROUTE . '/create', ['class'=>'needs-validation','novalidate'=>'novalidate']); ?>
      <div class="card">
        <div class="card-header border-0">
          <h4 class="card-title mb-0">New <?= $const['item']; ?></h4>
        </div>

        <div class="card-body border border-dashed">
            <!-- form.php contains product select AND the single attributes-wrapper -->
            <?= $this->include($const['viewfolder'] . "form"); ?>

            <?php if (session()->has('error')) : ?>
              <div class="row mt-3">
                <div class="col">
                  <div class="alert alert-danger" role="alert">
                    <ul style="margin-bottom:0px;">
                      <?php foreach ((array)session('error') as $error) : ?>
                        <li><?= $error ?></li>
                      <?php endforeach; ?>
                    </ul>
                  </div>
                </div>
              </div>
            <?php endif ?>
        </div>

        <div class="card-footer border-0 d-flex justify-content-end gap-2">
          <button type="submit" class="btn btn-primary btn-label rounded-pill"><i class="ri-check-double-line label-icon me-1"></i> Save</button>
          <a href="<?= site_url($const['route']); ?>" class="btn btn-danger btn-label rounded-pill"><i class="ri-close-line label-icon me-1"></i> Cancel</a>
        </div>
      </div>
    </form>
  </div>
</div>

<?= $this->endSection() ?>

<?= $this->section("footerjs") ?>
<script>
document.addEventListener("DOMContentLoaded", function () {
    var basePath = "<?= site_url(); ?>";
    const productSelect = document.querySelector('select[name="productId"]');
    const attributesRow = document.getElementById("attributes-row");
    const placeholder = document.getElementById("attributes-placeholder");

    function clearAttributeCols() {
        // remove any .attr-col elements (old attribute columns)
        const old = attributesRow.querySelectorAll('.attr-col');
        old.forEach(n => n.remove());
    }

    function syncProductHeight() {
    const productCol = document.getElementById('product-col');
    const attributesRow = document.getElementById('attributes-row');
    if (!productCol || !attributesRow) return;
    // Reset first
    productCol.style.minHeight = '';
    // setTimeout(() => {
    //     const target = attributesRow.offsetHeight || 0;
    //     // don't change for tiny diffs
    //     if (target <= productCol.offsetHeight + 8) {
    //         productCol.style.minHeight = '';
    //         return;
    //     }
    //     // cap to avoid huge gaps from unexpected content
    //     const cap = 120; // px — adjust if you want taller product box
    //     productCol.style.minHeight = Math.min(target, cap) + 'px';
    // }, 40);
}


    if (productSelect) {
        productSelect.addEventListener("change", function () {
            const pid = this.value;
            // clear existing attribute columns
            clearAttributeCols();

            if (!pid) {
                // restore placeholder
                if (placeholder && !attributesRow.contains(placeholder)) {
                    attributesRow.appendChild(placeholder);
                }
                syncProductHeight();
                return;
            }

            // remove placeholder (we will append columns directly into attributesRow)
            if (placeholder && attributesRow.contains(placeholder)) {
                placeholder.remove();
            }

            fetch(basePath + "<?= $const['route']; ?>/attributes/" + pid, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(r => {
                    if (!r.ok) throw new Error('Network response was not ok');
                    return r.text();
                })
                .then(html => {
                    // html MUST contain a sequence of <div class="col-md-3 col-sm-6 attr-col">...</div>
                    // Insert the columns as siblings inside attributesRow (after the product column)
                    attributesRow.insertAdjacentHTML('beforeend', html);
                    syncProductHeight();
                })
                .catch(err => {
                    console.error("Failed to load attributes", err);
                    // show a full-width error message (col-12)
                    attributesRow.insertAdjacentHTML('beforeend', '<div class="col-12 attr-col"><div class="alert alert-danger">Failed to load attributes</div></div>');
                    syncProductHeight();
                });
        });
    }
});
</script>

<?= $this->endSection() ?>

<?= $this->extend("Layouts/default") ?>
<?= $this->section("title") ?>Dashboard<?= $this->endSection() ?>
<?= $this->section("headercss") ?><?= $this->endSection() ?>
<?= $this->section("headerjs") ?><?= $this->endSection() ?>
<?= $this->section("content") ?>
<div class="row">
   <div class="col-xxl-5">
      <div class="d-flex flex-column h-100">
         <div class="row h-100">
            <div class="col-12">
               <div class="card">
                  <div class="card-body p-0">
                     <div class="alert alert-warning border-0 rounded-0 m-0 d-flex align-items-center" role="alert">
                        <i data-feather="alert-triangle" class="text-warning me-2 icon-sm"></i>
                        <div class="flex-grow-1 text-truncate">
                           Your free trial expired in <b>17</b> days.
                        </div>
                        <div class="flex-shrink-0">
                           <a href="pages-pricing.html" class="text-reset text-decoration-underline"><b>Upgrade</b></a>
                        </div>
                     </div>
                     <div class="row align-items-end">
                        <div class="col-sm-8">
                           <div class="p-3">
                              <p class="fs-16 lh-base">Upgrade your plan from a <span class="fw-semibold">Free trial</span>, to 'Premium Plan' <i class="mdi mdi-arrow-right"></i></p>
                              <div class="mt-3">
                                 <a href="pages-pricing.html" class="btn btn-success">Upgrade Account!</a>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="px-3">
                              <img src="<?= site_url(); ?>assets/images/user-illustarator-2.png" class="img-fluid" alt="">
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- end card-body-->
               </div>
            </div>
            <!-- end col-->
         </div>
         <!-- end row-->
         <div class="row">
            <div class="col-md-6">
               <div class="card card-animate">
                  <div class="card-body">
                     <div class="d-flex justify-content-between">
                        <div>
                           <p class="fw-medium text-muted mb-0">Total Orders</p>
                           <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value" data-target="28">0</span></h2>
                        </div>
                        <div>
                           <div class="avatar-sm flex-shrink-0">
                              <span class="avatar-title bg-info-subtle rounded-circle fs-2">
                              <i data-feather="users" class="text-info"></i>
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- end card body -->
               </div>
               <!-- end card-->
            </div>
            <!-- end col-->
            <div class="col-md-6">
               <div class="card card-animate">
                  <div class="card-body">
                     <div class="d-flex justify-content-between">
                        <div>
                           <p class="fw-medium text-muted mb-0">In-Transit</p>
                           <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value" data-target="20">0</span></h2>
                        </div>
                        <div>
                           <div class="avatar-sm flex-shrink-0">
                              <span class="avatar-title bg-info-subtle rounded-circle fs-2">
                              <i data-feather="users" class="text-info"></i>
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- end card body -->
               </div>
               <!-- end card-->
            </div>
            <!-- end col-->
         </div>
         <!-- end row-->
         <div class="row">
         <div class="col-md-6">
               <div class="card card-animate">
                  <div class="card-body">
                     <div class="d-flex justify-content-between">
                        <div>
                           <p class="fw-medium text-muted mb-0">Delivered</p>
                           <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value" data-target="8">0</span></h2>
                        </div>
                        <div>
                           <div class="avatar-sm flex-shrink-0">
                              <span class="avatar-title bg-info-subtle rounded-circle fs-2">
                              <i data-feather="users" class="text-info"></i>
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- end card body -->
               </div>
               <!-- end card-->
            </div>
            <!-- end col-->
            <div class="col-md-6">
               <div class="card card-animate">
                  <div class="card-body">
                     <div class="d-flex justify-content-between">
                        <div>
                           <p class="fw-medium text-muted mb-0">RTO</p>
                           <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value" data-target="2">0</span></h2>
                        </div>
                        <div>
                           <div class="avatar-sm flex-shrink-0">
                              <span class="avatar-title bg-info-subtle rounded-circle fs-2">
                              <i data-feather="users" class="text-info"></i>
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- end card body -->
               </div>
               <!-- end card-->
            </div>
            <!-- end col-->
         </div>
         <!-- end row-->
      </div>
   </div>
   <!-- end col-->
   <div class="col-xxl-7">
      <div class="row h-100">
         <div class="col-xl-6">
            <div class="card card-height-100">
               <div class="card-header border-0 align-items-center d-flex">
                  <h4 class="card-title mb-0 flex-grow-1">My Portfolio</h4>
                  <div>
                     <div class="dropdown">
                        <button class="btn btn-soft-primary btn-sm" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="text-uppercase">Btc<i class="mdi mdi-chevron-down align-middle ms-1"></i></span>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end">
                           <a class="dropdown-item" href="#">BTC</a>
                           <a class="dropdown-item" href="#">USD</a>
                           <a class="dropdown-item" href="#">Euro</a>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- end cardheader -->
               <div class="card-body">
                  <div id="portfolio_donut_charts" data-colors='["--vz-primary", "--vz-info", "--vz-warning", "--vz-success"]' class="apex-charts" dir="ltr"></div>
                  <ul class="list-group list-group-flush border-dashed mb-0 mt-3 pt-2">

                     <!-- end -->
                     <li class="list-group-item px-0">
                        <div class="d-flex">
                           <div class="flex-shrink-0 avatar-xs">
                              <span class="avatar-title bg-light p-1 rounded-circle">
                              <img src="assets/images/svg/crypto-icons/ltc.svg" class="img-fluid" alt="">
                              </span>
                           </div>
                           <div class="flex-grow-1 ms-2">
                              <h6 class="mb-1">Litecoin</h6>
                              <p class="fs-12 mb-0 text-muted"><i class="mdi mdi-circle fs-10 align-middle text-warning me-1"></i>LTC </p>
                           </div>
                           <div class="flex-shrink-0 text-end">
                              <h6 class="mb-1">LTC 10.58963217</h6>
                              <p class="text-success fs-12 mb-0">$15824.58</p>
                           </div>
                        </div>
                     </li>
                     <!-- end -->
                     <li class="list-group-item px-0 pb-0">
                        <div class="d-flex">
                           <div class="flex-shrink-0 avatar-xs">
                              <span class="avatar-title bg-light p-1 rounded-circle">
                              <img src="assets/images/svg/crypto-icons/dash.svg" class="img-fluid" alt="">
                              </span>
                           </div>
                           <div class="flex-grow-1 ms-2">
                              <h6 class="mb-1">Dash</h6>
                              <p class="fs-12 mb-0 text-muted"><i class="mdi mdi-circle fs-10 align-middle text-success me-1"></i>DASH </p>
                           </div>
                           <div class="flex-shrink-0 text-end">
                              <h6 class="mb-1">DASH 204.28565885</h6>
                              <p class="text-success fs-12 mb-0">$30635.84</p>
                           </div>
                        </div>
                     </li>
                     <!-- end -->
                     <li class="list-group-item px-0 pb-0">
                        <div class="d-flex">
                           <div class="flex-shrink-0 avatar-xs">
                              <span class="avatar-title bg-light p-1 rounded-circle">
                              <img src="assets/images/svg/crypto-icons/dash.svg" class="img-fluid" alt="">
                              </span>
                           </div>
                           <div class="flex-grow-1 ms-2">
                              <h6 class="mb-1">Dash</h6>
                              <p class="fs-12 mb-0 text-muted"><i class="mdi mdi-circle fs-10 align-middle text-success me-1"></i>DASH </p>
                           </div>
                           <div class="flex-shrink-0 text-end">
                              <h6 class="mb-1">DASH 204.28565885</h6>
                              <p class="text-success fs-12 mb-0">$30635.84</p>
                           </div>
                        </div>
                     </li>
                     <!-- end -->
                  </ul>
                  <!-- end -->
               </div>
               <!-- end card body -->
            </div>
            <!-- end card -->
         </div>
         <!-- end col -->
         <!-- end col -->
         <div class="col-xl-6">
            <!-- card -->
            <div class="card card-height-100">
               <div class="card-header align-items-center d-flex">
                  <h4 class="card-title mb-0 flex-grow-1">Sales by Locations</h4>
                  <div class="flex-shrink-0">
                     <button type="button" class="btn btn-soft-primary btn-sm">
                     Export Report
                     </button>
                  </div>
               </div>
               <!-- end card header -->
               <!-- card body -->
               <div class="card-body">
                  <div id="sales-by-locations" data-colors='["--vz-light", "--vz-success", "--vz-primary"]' style="height: 269px" dir="ltr"></div>
               </div>
               <!-- end card body -->
            </div>
            <!-- end card -->
            <!-- end card -->
         </div>
         <!-- end col-->
      </div>
      <!-- end row-->
   </div>
   <!-- end col -->
</div>
<!-- end row-->
<div class="row">
   <div class="col-xl-6">
      <div class="card">
         <div class="card-header align-items-center d-flex">
            <h4 class="card-title mb-0 flex-grow-1">Best Selling Products</h4>
            <div class="flex-shrink-0">
               <div class="dropdown card-header-dropdown">
                  <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="fw-semibold text-uppercase fs-12">Sort by:
                  </span><span class="text-muted">Today<i class="mdi mdi-chevron-down ms-1"></i></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-end">
                     <a class="dropdown-item" href="#">Today</a>
                     <a class="dropdown-item" href="#">Yesterday</a>
                     <a class="dropdown-item" href="#">Last 7 Days</a>
                     <a class="dropdown-item" href="#">Last 30 Days</a>
                     <a class="dropdown-item" href="#">This Month</a>
                     <a class="dropdown-item" href="#">Last Month</a>
                  </div>
               </div>
            </div>
         </div>
         <!-- end card header -->
         <div class="card-body">
            <div class="table-responsive table-card">
               <table class="table table-hover table-centered align-middle table-nowrap mb-0">
                  <tbody>
                     <tr>
                        <td>
                           <div class="d-flex align-items-center">
                              <div class="avatar-sm bg-light rounded p-1 me-2">
                                 <img src="<?= site_url(); ?>assets/images/products/img-1.png" alt="" class="img-fluid d-block" />
                              </div>
                              <div>
                                 <h5 class="fs-14 my-1"><a href="apps-ecommerce-product-details.html" class="text-reset">Branded T-Shirts</a></h5>
                                 <span class="text-muted">24 Apr 2021</span>
                              </div>
                           </div>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">$29.00</h5>
                           <span class="text-muted">Price</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">62</h5>
                           <span class="text-muted">Orders</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">510</h5>
                           <span class="text-muted">Stock</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">$1,798</h5>
                           <span class="text-muted">Amount</span>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <div class="d-flex align-items-center">
                              <div class="avatar-sm bg-light rounded p-1 me-2">
                                 <img src="<?= site_url(); ?>assets/images/products/img-2.png" alt="" class="img-fluid d-block" />
                              </div>
                              <div>
                                 <h5 class="fs-14 my-1"><a href="apps-ecommerce-product-details.html" class="text-reset">Bentwood Chair</a></h5>
                                 <span class="text-muted">19 Mar 2021</span>
                              </div>
                           </div>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">$85.20</h5>
                           <span class="text-muted">Price</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">35</h5>
                           <span class="text-muted">Orders</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal"><span class="badge bg-danger-subtle text-danger">Out of stock</span> </h5>
                           <span class="text-muted">Stock</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">$2982</h5>
                           <span class="text-muted">Amount</span>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <div class="d-flex align-items-center">
                              <div class="avatar-sm bg-light rounded p-1 me-2">
                                 <img src="<?= site_url(); ?>assets/images/products/img-3.png" alt="" class="img-fluid d-block" />
                              </div>
                              <div>
                                 <h5 class="fs-14 my-1"><a href="apps-ecommerce-product-details.html" class="text-reset">Borosil Paper Cup</a></h5>
                                 <span class="text-muted">01 Mar 2021</span>
                              </div>
                           </div>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">$14.00</h5>
                           <span class="text-muted">Price</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">80</h5>
                           <span class="text-muted">Orders</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">749</h5>
                           <span class="text-muted">Stock</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">$1120</h5>
                           <span class="text-muted">Amount</span>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <div class="d-flex align-items-center">
                              <div class="avatar-sm bg-light rounded p-1 me-2">
                                 <img src="<?= site_url(); ?>assets/images/products/img-4.png" alt="" class="img-fluid d-block" />
                              </div>
                              <div>
                                 <h5 class="fs-14 my-1"><a href="apps-ecommerce-product-details.html" class="text-reset">One Seater Sofa</a></h5>
                                 <span class="text-muted">11 Feb 2021</span>
                              </div>
                           </div>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">$127.50</h5>
                           <span class="text-muted">Price</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">56</h5>
                           <span class="text-muted">Orders</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal"><span class="badge bg-danger-subtle text-danger">Out of stock</span></h5>
                           <span class="text-muted">Stock</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">$7140</h5>
                           <span class="text-muted">Amount</span>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <div class="d-flex align-items-center">
                              <div class="avatar-sm bg-light rounded p-1 me-2">
                                 <img src="<?= site_url(); ?>assets/images/products/img-5.png" alt="" class="img-fluid d-block" />
                              </div>
                              <div>
                                 <h5 class="fs-14 my-1"><a href="apps-ecommerce-product-details.html" class="text-reset">Stillbird Helmet</a></h5>
                                 <span class="text-muted">17 Jan 2021</span>
                              </div>
                           </div>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">$54</h5>
                           <span class="text-muted">Price</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">74</h5>
                           <span class="text-muted">Orders</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">805</h5>
                           <span class="text-muted">Stock</span>
                        </td>
                        <td>
                           <h5 class="fs-14 my-1 fw-normal">$3996</h5>
                           <span class="text-muted">Amount</span>
                        </td>
                     </tr>
                  </tbody>
               </table>
            </div>
            <div class="align-items-center mt-4 pt-2 justify-content-between row text-center text-sm-start">
               <div class="col-sm">
                  <div class="text-muted">
                     Showing <span class="fw-semibold">5</span> of <span class="fw-semibold">25</span> Results
                  </div>
               </div>
               <div class="col-sm-auto  mt-3 mt-sm-0">
                  <ul class="pagination pagination-separated pagination-sm mb-0 justify-content-center">
                     <li class="page-item disabled">
                        <a href="#" class="page-link">←</a>
                     </li>
                     <li class="page-item">
                        <a href="#" class="page-link">1</a>
                     </li>
                     <li class="page-item active">
                        <a href="#" class="page-link">2</a>
                     </li>
                     <li class="page-item">
                        <a href="#" class="page-link">3</a>
                     </li>
                     <li class="page-item">
                        <a href="#" class="page-link">→</a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="col-xl-6">
      <div class="card card-height-100">
         <div class="card-header align-items-center d-flex">
            <h4 class="card-title mb-0 flex-grow-1">Top Sellers</h4>
            <div class="flex-shrink-0">
               <div class="dropdown card-header-dropdown">
                  <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="text-muted">Report<i class="mdi mdi-chevron-down ms-1"></i></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-end">
                     <a class="dropdown-item" href="#">Download Report</a>
                     <a class="dropdown-item" href="#">Export</a>
                     <a class="dropdown-item" href="#">Import</a>
                  </div>
               </div>
            </div>
         </div>
         <!-- end card header -->
         <div class="card-body">
            <div class="table-responsive table-card">
               <table class="table table-centered table-hover align-middle table-nowrap mb-0">
                  <tbody>
                     <tr>
                        <td>
                           <div class="d-flex align-items-center">
                              <div class="flex-shrink-0 me-2">
                                 <img src="<?= site_url(); ?>assets/images/companies/img-1.png" alt="" class="avatar-sm p-2" />
                              </div>
                              <div>
                                 <h5 class="fs-14 my-1 fw-medium">
                                    <a href="apps-ecommerce-seller-details.html" class="text-reset">iTest Factory</a>
                                 </h5>
                                 <span class="text-muted">Oliver Tyler</span>
                              </div>
                           </div>
                        </td>
                        <td>
                           <span class="text-muted">Bags and Wallets</span>
                        </td>
                        <td>
                           <p class="mb-0">8547</p>
                           <span class="text-muted">Stock</span>
                        </td>
                        <td>
                           <span class="text-muted">$541200</span>
                        </td>
                        <td>
                           <h5 class="fs-14 mb-0">32%<i class="ri-bar-chart-fill text-success fs-16 align-middle ms-2"></i></h5>
                        </td>
                     </tr>
                     <!-- end -->
                     <tr>
                        <td>
                           <div class="d-flex align-items-center">
                              <div class="flex-shrink-0 me-2">
                                 <img src="<?= site_url(); ?>assets/images/companies/img-2.png" alt="" class="avatar-sm p-2" />
                              </div>
                              <div class="flex-grow-1">
                                 <h5 class="fs-14 my-1 fw-medium"><a href="apps-ecommerce-seller-details.html" class="text-reset">Digitech Galaxy</a></h5>
                                 <span class="text-muted">John Roberts</span>
                              </div>
                           </div>
                        </td>
                        <td>
                           <span class="text-muted">Watches</span>
                        </td>
                        <td>
                           <p class="mb-0">895</p>
                           <span class="text-muted">Stock</span>
                        </td>
                        <td>
                           <span class="text-muted">$75030</span>
                        </td>
                        <td>
                           <h5 class="fs-14 mb-0">79%<i class="ri-bar-chart-fill text-success fs-16 align-middle ms-2"></i></h5>
                        </td>
                     </tr>
                     <!-- end -->
                     <tr>
                        <td>
                           <div class="d-flex align-items-center">
                              <div class="flex-shrink-0 me-2">
                                 <img src="<?= site_url(); ?>assets/images/companies/img-3.png" alt="" class="avatar-sm p-2" />
                              </div>
                              <div class="flex-gow-1">
                                 <h5 class="fs-14 my-1 fw-medium"><a href="apps-ecommerce-seller-details.html" class="text-reset">Nesta Technologies</a></h5>
                                 <span class="text-muted">Harley Fuller</span>
                              </div>
                           </div>
                        </td>
                        <td>
                           <span class="text-muted">Bike Accessories</span>
                        </td>
                        <td>
                           <p class="mb-0">3470</p>
                           <span class="text-muted">Stock</span>
                        </td>
                        <td>
                           <span class="text-muted">$45600</span>
                        </td>
                        <td>
                           <h5 class="fs-14 mb-0">90%<i class="ri-bar-chart-fill text-success fs-16 align-middle ms-2"></i></h5>
                        </td>
                     </tr>
                     <!-- end -->
                     <tr>
                        <td>
                           <div class="d-flex align-items-center">
                              <div class="flex-shrink-0 me-2">
                                 <img src="<?= site_url(); ?>assets/images/companies/img-8.png" alt="" class="avatar-sm p-2" />
                              </div>
                              <div class="flex-grow-1">
                                 <h5 class="fs-14 my-1 fw-medium"><a href="apps-ecommerce-seller-details.html" class="text-reset">Zoetic Fashion</a></h5>
                                 <span class="text-muted">James Bowen</span>
                              </div>
                           </div>
                        </td>
                        <td>
                           <span class="text-muted">Clothes</span>
                        </td>
                        <td>
                           <p class="mb-0">5488</p>
                           <span class="text-muted">Stock</span>
                        </td>
                        <td>
                           <span class="text-muted">$29456</span>
                        </td>
                        <td>
                           <h5 class="fs-14 mb-0">40%<i class="ri-bar-chart-fill text-success fs-16 align-middle ms-2"></i></h5>
                        </td>
                     </tr>
                     <!-- end -->
                     <tr>
                        <td>
                           <div class="d-flex align-items-center">
                              <div class="flex-shrink-0 me-2">
                                 <img src="<?= site_url(); ?>assets/images/companies/img-5.png" alt="" class="avatar-sm p-2" />
                              </div>
                              <div class="flex-grow-1">
                                 <h5 class="fs-14 my-1 fw-medium">
                                    <a href="apps-ecommerce-seller-details.html" class="text-reset">Meta4Systems</a>
                                 </h5>
                                 <span class="text-muted">Zoe Dennis</span>
                              </div>
                           </div>
                        </td>
                        <td>
                           <span class="text-muted">Furniture</span>
                        </td>
                        <td>
                           <p class="mb-0">4100</p>
                           <span class="text-muted">Stock</span>
                        </td>
                        <td>
                           <span class="text-muted">$11260</span>
                        </td>
                        <td>
                           <h5 class="fs-14 mb-0">57%<i class="ri-bar-chart-fill text-success fs-16 align-middle ms-2"></i></h5>
                        </td>
                     </tr>
                     <!-- end -->
                  </tbody>
               </table>
               <!-- end table -->
            </div>
            <div class="align-items-center mt-4 pt-2 justify-content-between row text-center text-sm-start">
               <div class="col-sm">
                  <div class="text-muted">
                     Showing <span class="fw-semibold">5</span> of <span class="fw-semibold">25</span> Results
                  </div>
               </div>
               <div class="col-sm-auto  mt-3 mt-sm-0">
                  <ul class="pagination pagination-separated pagination-sm mb-0 justify-content-center">
                     <li class="page-item disabled">
                        <a href="#" class="page-link">←</a>
                     </li>
                     <li class="page-item">
                        <a href="#" class="page-link">1</a>
                     </li>
                     <li class="page-item active">
                        <a href="#" class="page-link">2</a>
                     </li>
                     <li class="page-item">
                        <a href="#" class="page-link">3</a>
                     </li>
                     <li class="page-item">
                        <a href="#" class="page-link">→</a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
         <!-- .card-body-->
      </div>
      <!-- .card-->
   </div>
   <!-- .col-->
</div>
<!-- end row-->
<?= $this->endSection() ?>
<?= $this->section("footerjs") ?>
<script src="<?= site_url(); ?>assets/libs/apexcharts/apexcharts.min.js"></script>
<script src="<?= site_url(); ?>assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
<script src="<?= site_url(); ?>assets/libs/jsvectormap/maps/world-merc.js"></script>
<script src="<?= site_url(); ?>assets/libs/swiper/swiper-bundle.min.js"></script>
<script src="<?= site_url(); ?>assets/js/pages/dashboard-ecommerce.init.js"></script>
<!-- apexcharts -->
<script src="<?= site_url(); ?>assets/libs/apexcharts/apexcharts.min.js"></script>
<script src="<?= site_url(); ?>assets/libs/swiper/swiper-bundle.min.js"></script>
<script src="<?= site_url(); ?>assets/js/pages/dashboard-crypto.init.js"></script>
<script src="<?= site_url(); ?>assets/libs/sweetalert2/sweetalert2.min.js"></script>
<!-- Page JS -->
<?php if (session()->has('success')) : ?>
      <script>
         var t;
         Swal.fire({
            title: "Good job!",
            icon: "success",
            html: "<?= session('success') ?>",
            timer: 2e3,
            timerProgressBar: !0,
            didOpen: function() {
               Swal.showLoading(), t = setInterval(function() {
                  var t, e = Swal.getHtmlContainer();
                  !e || (t = e.querySelector("b")) && (t.textContent = Swal.getTimerLeft())
               }, 100)
            },
            onClose: function() {
               clearInterval(t)
            }
         });
      </script>
   <?php endif; ?>
   <?php if (session()->has('warning')) : ?>
      <script>
         Swal.fire({
            title: 'Oops, Sorry!',
            text: "<?= session('warning') ?>",
            icon: "warning",
            padding: '2em'
         });
      </script>
   <?php endif; ?>
   <?php if (session()->has('danger')) : ?>
      <script>
         Swal.fire({
            title: 'Oops, Sorry!',
            text: "<?= session('danger') ?>",
            icon: "warning",
            padding: '2em'
         });
      </script>
   <?php endif; ?>
   <?php if (session()->has('reload')) : ?>
      <script>
         var t;
         Swal.fire({
            title: "Please wait !",
            icon: "info",
            html: "<?= session('reload') ?>",
            timer: 2e3,
            timerProgressBar: !0,
            didOpen: function() {
               Swal.showLoading(), t = setInterval(function() {
                  var t, e = Swal.getHtmlContainer();
                  !e || (t = e.querySelector("b")) && (t.textContent = Swal.getTimerLeft())
               }, 100)
            },
            onClose: function() {
               clearInterval(t)
            }
         });
      </script>
   <?php endif; ?>
   <!-- Page JS -->
<?= $this->endSection() ?>

<?php

    $this->login = new \App\Models\Login;
    $this->permissions = new \App\Models\Permissions;
    $this->rolePermissions = new \App\Models\RolePermissions;
    $this->roles = new \App\Models\Roles

?>